using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    public GameObject player;
    public GameObject Cam1;
    public GameObject Cam2;
    
    private Vector3 offset;

    // Start is called before the first frame update
    void Start()
    {
        offset = transform.position - player.transform.position;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        transform.position = player.transform.position + offset;
    }
    void Update()
    {
       
        if (transform.position.z > 50)
        {
            Cam1.SetActive(false);
            Cam2.SetActive(true);
        }
        if (transform.position.z < 40)
        {
            Cam1.SetActive(true);
            Cam2.SetActive(false);
        }

    }

}
